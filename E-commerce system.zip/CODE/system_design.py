# User Class
class User:
    def __init__(self, user_id, name, email):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.orders = []

    def create_order(self, order):
        self.orders.append(order)

    def view_order(self, order_id):
        for order in self.orders:
            if order.order_id == order_id:
                return order
        return None

    def manage_order(self, order_id, action):
        order = self.view_order(order_id)
        if order:
            if action == 'cancel':
                order.status = 'cancelled'
            # Add more actions as necessary
        return order

# Product Class
class Product:
    def __init__(self, product_id, name, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.stock_quantity = stock_quantity

# Order Class
class Order:
    def __init__(self, order_id, user):
        self.order_id = order_id
        self.user = user
        self.products = []
        self.status = 'pending'

    def add_product(self, product):
        self.products.append(product)

    def remove_product(self, product):
        self.products.remove(product)

    def get_total(self):
        total = sum([product.price for product in self.products])
        return total

# Payment Class
class Payment:
    def __init__(self, payment_id, order, amount):
        self.payment_id = payment_id
        self.order = order
        self.amount = amount
        self.status = 'pending'

    def process_payment(self):
        if self.amount == self.order.get_total():
            self.status = 'paid'
            self.order.status = 'completed'
        else:
            raise ValueError("Payment amount doesn't match order total.")
        

