import mysql.connector
from mysql.connector import Error
from business_logic import Product_Inventory


def create_connection(host_name, user_name, user_password, db_name):
    """Create a database connection to a MySQL database."""
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,  #your hostname
            user=user_name,  # Your MySQL username
            password=user_password,  # Your MySQL password
            database=db_name   # The database you created earlier
        )
        print("Connection to MySQL DB successful")
    except Error as e:
        print(f"The error '{e}' occurred")

    return connection

def execute_query(connection, query):
    """Execute a single query."""
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        connection.commit()
        print("Query executed successfully")
    except Error as e:
        print(f"The error '{e}' occurred")

def fetch_query_results(connection, query):
    """Fetch results from a query."""
    cursor = connection.cursor()
    cursor.execute(query)
    results = cursor.fetchall()
    return results

# Database credentials
host = 'localhost'  # Your host
user = 'your_username'  # Your MySQL username
password = 'your_password'  # Your MySQL password
database = 'your_database'  # Your database name

# Establish connection
connection = create_connection(host, user, password, database)

# SQL Queries
query1 = """
SELECT c.customer_id, c.name, SUM(od.quantity) AS total_books
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id
JOIN OrderDetails od ON o.order_id = od.order_id
WHERE o.order_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY c.customer_id, c.name
ORDER BY total_books DESC
LIMIT 5;
"""

query2 = """
SELECT b.author, SUM(od.quantity * b.price) AS total_revenue
FROM Books b
JOIN OrderDetails od ON b.book_id = od.book_id
GROUP BY b.author
ORDER BY total_revenue DESC;
"""

query3 = """
SELECT b.book_id, b.title, SUM(od.quantity) AS total_quantity_ordered
FROM Books b
JOIN OrderDetails od ON b.book_id = od.book_id
GROUP BY b.book_id, b.title
HAVING total_quantity_ordered > 10
ORDER BY total_quantity_ordered DESC;
"""

# Execute and fetch results
print("Top 5 Customers:")
results1 = fetch_query_results(connection, query1)
for row in results1:
    print(row)

print("\nTotal Revenue by Author:")
results2 = fetch_query_results(connection, query2)
for row in results2:
    print(row)

print("\nBooks Ordered More Than 10 Times:")
results3 = fetch_query_results(connection, query3)
for row in results3:
    print(row)

# Close the connection
if connection:
    connection.close()
    print("Connection closed.")
