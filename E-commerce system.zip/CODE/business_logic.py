# ProductInventory class to manage stock levels and restocking
class Product_Inventory:
    def __init__(self, product_id, name, stock_level, threshold=10):
        self.product_id = product_id
        self.name = name
        self.stock_level = stock_level
        self.threshold = threshold

    def reduce_stock(self, quantity):
        if self.stock_level >= quantity:
            self.stock_level -= quantity
        else:
            raise ValueError(f"Insufficient stock for product: {self.name}")

    def needs_restock(self):
        return self.stock_level < self.threshold

    def restock(self, quantity):
        self.stock_level += quantity

# OrderProcessing class to handle incoming orders and restocking alerts
class Order_Processing:
    def __init__(self, products):
        """
        :param products: A dictionary of product_id to ProductInventory objects
        """
        self.products = products

    def process_orders(self, orders):
        """
        Processes incoming sales orders and reduces stock levels accordingly.
        :param orders: A list of dictionaries with product_id and quantity ordered
        """
        restock_alerts = []

        for order in orders:
            product_id = order['product_id']
            quantity = order['quantity']

            if product_id in self.products:
                product = self.products[product_id]
                try:
                    product.reduce_stock(quantity)
                    print(f"Processed order for {quantity} units of {product.name}. New stock level: {product.stock_level}")

                    # Trigger restock alert if stock falls below threshold
                    if product.needs_restock():
                        restock_alerts.append(product.name)
                except ValueError as e:
                    print(e)
            else:
                print(f"Product with ID {product_id} not found in inventory.")

        if restock_alerts:
            print(f"Restock required for: {', '.join(restock_alerts)}")

    def restock_items(self, restock_list):
        """
        Restocks products based on restock list.
        :param restock_list: A list of dictionaries with product_id and quantity to restock
        """
        for item in restock_list:
            product_id = item['product_id']
            quantity = item['quantity']

            if product_id in self.products:
                product = self.products[product_id]
                product.restock(quantity)
                print(f"Restocked {quantity} units of {product.name}. New stock level: {product.stock_level}")
            else:
                print(f"Product with ID {product_id} not found in inventory.")
